"use client";

import ProtectedRoute from "@/components/admin/auth/protected-route";
import DashboardLayout from "@/components/admin/layout/dashboard-layout";
import { FileUpload } from "@/components/admin/ui/form-components";
import Input from "@/components/Input";
import { Button } from "@/components/ui/button";
import { Profile } from "@/lib/api";
import { User, Save } from "lucide-react";

const HomeBody: React.FC<{
  userProfile: Profile;
  
}> = ({ userProfile }) => {

    return(
         <ProtectedRoute>
              <DashboardLayout>
                <div className="max-w-4xl mx-auto">
                <div className="mb-8">
                  <h1 className="text-3xl font-bold text-gray-900 dark:text-white flex items-center">
                    <User className="mr-3 h-8 w-8 text-blue-600" />
                    Profile Management
                    {userProfile?.firstName}
                  </h1>
                  <p className="mt-2 text-gray-600 dark:text-gray-400">
                    Update your personal information and profile details
                  </p>
                </div>
        
                {/* {errors.general && (
                  <div className="mb-6 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-md p-4">
                    <p className="text-red-600 dark:text-red-400">{errors.general}</p>
                  </div>
                )} */}
        
                {/* <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="bg-white dark:bg-gray-800 shadow rounded-lg p-6">
                    <h2 className="text-lg font-medium text-gray-900 dark:text-white mb-6">
                      Personal Information
                    </h2>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <Input
                        label="Full Name"
                        value={formData.name}
                        onChange={(e) => handleInputChange('name', e.target.value)}
                        placeholder="Enter your full name"
                        error={errors.name}
                        required
                      />
                      
                      <Input
                        label="Email Address"
                        type="email"
                        value={formData.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        placeholder="Enter your email address"
                        error={errors.email}
                        required
                      />
                    </div>
        
                    <div className="mt-6">
                      <Input
                        label="Professional Tagline"
                        // value={formData.tagline}
                        onChange={(e) => handleInputChange('tagline', e.target.value)}
                        placeholder="e.g., Full-Stack Developer passionate about creating amazing web experiences"
                        error={errors.tagline}
                        required
                      />
                    </div>
        
                    <div className="mt-6">
                      <FileUpload
                        label="Profile Picture"
                        accept="image/*"
                        onChange={(file) => handleInputChange('profilePicture', file)}
                        // currentFile={userProfile?.profilePicture}
                        error={errors.profilePicture}
                      />
                    </div>
                  </div>
        
                  <div className="flex justify-end space-x-4">
                    <Button
                      type="submit"
                      loading={updateProfileMutation.isPending}
                      icon={Save}
                    >
                      Save Changes
                    </Button>
                  </div>
                </form> */}
        
                {/* {updateProfileMutation.isSuccess && (
                  <div className="mt-6 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-md p-4">
                    <p className="text-green-600 dark:text-green-400">
                      Profile updated successfully!
                    </p>
                  </div>
                )} */}
              </div>
              </DashboardLayout>
            </ProtectedRoute>
    )
}

export default HomeBody;
