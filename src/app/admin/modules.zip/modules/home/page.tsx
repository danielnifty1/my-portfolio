"use client"
import { use } from "react";
import HomeBody from "./homeBody";
import { API_BASE_URL } from "@/lib/api";


export default function ProfilePage() {
    const token = localStorage.getItem('admin_token');

const fetchValue = async () => {
    try {
      const rest = await fetch(`${API_BASE_URL}admin/profile`,
       {
          method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
          "Authorization":`Bearer ${token}`

        },
       }
      );
      const results = await rest.json();
      console.log("my dataz",results);

      return results.data;
    } catch (error) {
      console.error("An error occur, kindly review your network:", error);
      return [];
    }
  };
  const fetchAbout = async () => {
    try {
      const res = await fetch(`${API_BASE_URL}/api/about-uses`);
      const result = await res.json();

      return result.data;
      // return cat
    } catch (error) {
      console.error("An error occur, kindly review your network:", error);
      return null;
    }
  };

  const values = use(fetchValue());
  const profile = use(fetchAbout());

  return <HomeBody userProfile={profile} />;

}