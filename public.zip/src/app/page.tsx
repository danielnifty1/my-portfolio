import { Hero } from '@/components/sections/hero'
import { About } from '@/components/sections/about'
import { Skills } from '@/components/sections/skills'
import { Languages } from '@/components/sections/languages'
import { ProjectsDone } from '@/components/sections/projects-done'
import { ProjectsToDo } from '@/components/sections/projects-todo'
import { Contact } from '@/components/sections/contact'

export default function Home() {
  return (
    <div className="min-h-screen">
      <Hero />
      <About />
      <Skills />
      <Languages />
      <ProjectsDone />
      <ProjectsToDo />
      <Contact />
    </div>
  )
}
