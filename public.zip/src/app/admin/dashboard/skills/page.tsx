'use client';

import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { skillsAPI, Skill, CreateSkillData } from '@/lib/api';
import { Input, Select, Button } from '@/components/admin/ui/form-components';
import { Code, Plus, Edit, Trash2, Loader2, X } from 'lucide-react';
import DashboardLayout from '@/components/admin/layout/dashboard-layout';
import ProtectedRoute from '@/components/admin/auth/protected-route';

const categoryOptions = [
  { value: 'frontend', label: 'Frontend Development' },
  { value: 'backend', label: 'Backend Development' },
  { value: 'database', label: 'Database' },
  { value: 'devops', label: 'DevOps & Cloud' },
  { value: 'mobile', label: 'Mobile Development' },
  { value: 'other', label: 'Other' }
];

const proficiencyOptions = [
  { value: '25', label: 'Beginner (25%)' },
  { value: '50', label: 'Intermediate (50%)' },
  { value: '75', label: 'Advanced (75%)' },
  { value: '100', label: 'Expert (100%)' }
];

export default function SkillsPage() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSkill, setEditingSkill] = useState<Skill | null>(null);
  const [formData, setFormData] = useState<CreateSkillData>({
    name: '',
    category: '',
    proficiency: 50,
    icon: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const queryClient = useQueryClient();

  // Fetch skills
  const { data: skills, isLoading, error } = useQuery({
    queryKey: ['skills'],
    queryFn: skillsAPI.getSkills,
  });

  // Create skill mutation
  const createSkillMutation = useMutation({
    mutationFn: skillsAPI.createSkill,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['skills'] });
      handleCloseModal();
    },
    onError: (error: any) => {
      if (error.response?.data?.errors) {
        setErrors(error.response.data.errors);
      } else {
        setErrors({ general: 'Failed to create skill. Please try again.' });
      }
    },
  });

  // Update skill mutation
  const updateSkillMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<CreateSkillData> }) =>
      skillsAPI.updateSkill(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['skills'] });
      handleCloseModal();
    },
    onError: (error: any) => {
      if (error.response?.data?.errors) {
        setErrors(error.response.data.errors);
      } else {
        setErrors({ general: 'Failed to update skill. Please try again.' });
      }
    },
  });

  // Delete skill mutation
  const deleteSkillMutation = useMutation({
    mutationFn: skillsAPI.deleteSkill,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['skills'] });
    },
  });

  const handleOpenModal = (skill?: Skill) => {
    if (skill) {
      setEditingSkill(skill);
      setFormData({
        name: skill.name,
        category: skill.category,
        proficiency: skill.proficiency,
        icon: skill.icon || '',
      });
    } else {
      setEditingSkill(null);
      setFormData({
        name: '',
        category: '',
        proficiency: 50,
        icon: '',
      });
    }
    setErrors({});
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingSkill(null);
    setFormData({
      name: '',
      category: '',
      proficiency: 50,
      icon: '',
    });
    setErrors({});
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingSkill) {
      updateSkillMutation.mutate({ id: editingSkill.id, data: formData });
    } else {
      createSkillMutation.mutate(formData);
    }
  };

  const handleDeleteSkill = (id: string) => {
    if (confirm('Are you sure you want to delete this skill? This action cannot be undone.')) {
      deleteSkillMutation.mutate(id);
    }
  };

  const getProficiencyColor = (proficiency: number) => {
    if (proficiency <= 25) return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
    if (proficiency <= 50) return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
    if (proficiency <= 75) return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
    return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      frontend: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
      backend: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
      database: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
      devops: 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200',
      mobile: 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200',
      other: 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300',
    };
    return colors[category] || colors.other;
  };

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
        </div>
      </DashboardLayout>
    );
  }

  if (error) {
    return (
      <DashboardLayout>
        <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-md p-4">
          <p className="text-red-600 dark:text-red-400">
            Failed to load skills. Please refresh the page.
          </p>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <ProtectedRoute>
      <DashboardLayout>
        <div className="max-w-7xl mx-auto">
        <div className="mb-8 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white flex items-center">
              <Code className="mr-3 h-8 w-8 text-blue-600" />
              Skills Management
            </h1>
            <p className="mt-2 text-gray-600 dark:text-gray-400">
              Manage your technical skills and expertise
            </p>
          </div>
          <Button onClick={() => handleOpenModal()} icon={Plus}>
            Add Skill
          </Button>
        </div>

        {/* Skills Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {skills?.map((skill) => (
            <div key={skill.id} className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                    {skill.name}
                  </h3>
                  <div className="flex flex-wrap gap-2 mb-3">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getCategoryColor(skill.category)}`}>
                      {skill.category}
                    </span>
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getProficiencyColor(skill.proficiency)}`}>
                      {skill.proficiency}%
                    </span>
                  </div>
                </div>
                {skill.icon && (
                  <div className="ml-4 text-2xl">{skill.icon}</div>
                )}
              </div>

              {/* Proficiency Bar */}
              <div className="mb-4">
                <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400 mb-1">
                  <span>Proficiency</span>
                  <span>{skill.proficiency}%</span>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full transition-all duration-300 ${
                      skill.proficiency <= 25 ? 'bg-red-500' :
                      skill.proficiency <= 50 ? 'bg-yellow-500' :
                      skill.proficiency <= 75 ? 'bg-blue-500' : 'bg-green-500'
                    }`}
                    style={{ width: `${skill.proficiency}%` }}
                  />
                </div>
              </div>

              <div className="flex space-x-2">
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() => handleOpenModal(skill)}
                  icon={Edit}
                >
                  Edit
                </Button>
                <Button
                  size="sm"
                  variant="danger"
                  onClick={() => handleDeleteSkill(skill.id)}
                  icon={Trash2}
                  loading={deleteSkillMutation.isPending}
                >
                  Delete
                </Button>
              </div>
            </div>
          ))}
        </div>

        {skills?.length === 0 && (
          <div className="text-center py-12">
            <Code className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-2 text-sm font-medium text-gray-900 dark:text-white">No skills</h3>
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
              Get started by adding your first skill.
            </p>
            <div className="mt-6">
              <Button onClick={() => handleOpenModal()} icon={Plus}>
                Add Skill
              </Button>
            </div>
          </div>
        )}

        {/* Modal */}
        {isModalOpen && (
          <div className="fixed inset-0 z-50 overflow-y-auto">
            <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
              <div className="fixed inset-0 transition-opacity" onClick={handleCloseModal}>
                <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
              </div>

              <div className="inline-block align-bottom bg-white dark:bg-gray-800 rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
                <div className="bg-white dark:bg-gray-800 px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                      {editingSkill ? 'Edit Skill' : 'Add New Skill'}
                    </h3>
                    <button
                      onClick={handleCloseModal}
                      className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                    >
                      <X className="h-6 w-6" />
                    </button>
                  </div>

                  {errors.general && (
                    <div className="mb-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-md p-3">
                      <p className="text-sm text-red-600 dark:text-red-400">{errors.general}</p>
                    </div>
                  )}

                  <form onSubmit={handleSubmit} className="space-y-4">
                    <Input
                      label="Skill Name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="e.g., React, Node.js, Python"
                      error={errors.name}
                      required
                    />

                    <Select
                      label="Category"
                      value={formData.category}
                      onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                      options={categoryOptions}
                      error={errors.category}
                      required
                    />

                    <Select
                      label="Proficiency Level"
                      value={formData.proficiency.toString()}
                      onChange={(e) => setFormData({ ...formData, proficiency: parseInt(e.target.value) })}
                      options={proficiencyOptions}
                      error={errors.proficiency}
                      required
                    />

                    <Input
                      label="Icon (Emoji or Unicode)"
                      value={formData.icon}
                      onChange={(e) => setFormData({ ...formData, icon: e.target.value })}
                      placeholder="🚀 or 🔥 or leave empty"
                      error={errors.icon}
                    />
                  </form>
                </div>

                <div className="bg-gray-50 dark:bg-gray-700 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                  <Button
                    onClick={handleSubmit}
                    loading={createSkillMutation.isPending || updateSkillMutation.isPending}
                    className="w-full sm:w-auto sm:ml-3"
                  >
                    {editingSkill ? 'Update Skill' : 'Create Skill'}
                  </Button>
                  <Button
                    variant="secondary"
                    onClick={handleCloseModal}
                    className="mt-3 w-full sm:w-auto sm:mt-0"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
