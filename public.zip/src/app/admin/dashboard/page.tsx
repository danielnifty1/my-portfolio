'use client';

import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { profileAPI } from '@/lib/api';
import { Input, Textarea, FileUpload, Button } from '@/components/admin/ui/form-components';
import { User, Save, Loader2 } from 'lucide-react';
import DashboardLayout from '@/components/admin/layout/dashboard-layout';
import ProtectedRoute from '@/components/admin/auth/protected-route';

export default function DashboardPage() {
  const [formData, setFormData] = useState({
    name: '',
    tagline: '',
    email: '',
    profilePicture: null as File | null,
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const queryClient = useQueryClient();

  // Fetch profile data
  const { data: profile, isLoading, error } = useQuery({
    queryKey: ['profile'],
    queryFn: profileAPI.getProfile,
  });

  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: profileAPI.updateProfile,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['profile'] });
      setErrors({});
    },
    onError: (error: any) => {
      if (error.response?.data?.errors) {
        setErrors(error.response.data.errors);
      } else {
        setErrors({ general: 'Failed to update profile. Please try again.' });
      }
    },
  });

  // Update form data when profile is loaded
  useEffect(() => {
    if (profile) {
      setFormData({
        name: profile.name || '',
        tagline: profile.tagline || '',
        email: profile.email || '',
        profilePicture: null,
      });
    }
  }, [profile]);

  const handleInputChange = (field: string, value: string | File | null) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const updateData: any = {
      name: formData.name,
      tagline: formData.tagline,
      email: formData.email,
    };

    if (formData.profilePicture) {
      updateData.profilePicture = formData.profilePicture;
    }

    updateProfileMutation.mutate(updateData);
  };

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
        </div>
      </DashboardLayout>
    );
  }

  // if (error) {
  //   return (
  //     <DashboardLayout>
  //       <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-md p-4">
  //         <p className="text-red-600 dark:text-red-400">
  //           Failed to load profile. Please refresh the page.
  //         </p>
  //       </div>
  //     </DashboardLayout>
  //   );
  // }

  return (
    <ProtectedRoute>
      <DashboardLayout>
        <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white flex items-center">
            <User className="mr-3 h-8 w-8 text-blue-600" />
            Profile Management
          </h1>
          <p className="mt-2 text-gray-600 dark:text-gray-400">
            Update your personal information and profile details
          </p>
        </div>

        {errors.general && (
          <div className="mb-6 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-md p-4">
            <p className="text-red-600 dark:text-red-400">{errors.general}</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="bg-white dark:bg-gray-800 shadow rounded-lg p-6">
            <h2 className="text-lg font-medium text-gray-900 dark:text-white mb-6">
              Personal Information
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input
                label="Full Name"
                value={formData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                placeholder="Enter your full name"
                error={errors.name}
                required
              />
              
              <Input
                label="Email Address"
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                placeholder="Enter your email address"
                error={errors.email}
                required
              />
            </div>

            <div className="mt-6">
              <Input
                label="Professional Tagline"
                value={formData.tagline}
                onChange={(e) => handleInputChange('tagline', e.target.value)}
                placeholder="e.g., Full-Stack Developer passionate about creating amazing web experiences"
                error={errors.tagline}
                required
              />
            </div>

            <div className="mt-6">
              <FileUpload
                label="Profile Picture"
                accept="image/*"
                onChange={(file) => handleInputChange('profilePicture', file)}
                currentFile={profile?.profilePicture}
                error={errors.profilePicture}
              />
            </div>
          </div>

          <div className="flex justify-end space-x-4">
            <Button
              type="submit"
              loading={updateProfileMutation.isPending}
              icon={Save}
            >
              Save Changes
            </Button>
          </div>
        </form>

        {updateProfileMutation.isSuccess && (
          <div className="mt-6 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-md p-4">
            <p className="text-green-600 dark:text-green-400">
              Profile updated successfully!
            </p>
          </div>
        )}
      </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
