'use client';

import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { aboutAPI } from '@/lib/api';
import { Textarea, Button } from '@/components/admin/ui/form-components';
import { FileText, Save, Loader2 } from 'lucide-react';
import DashboardLayout from '@/components/admin/layout/dashboard-layout';
import ProtectedRoute from '@/components/admin/auth/protected-route';

export default function AboutMePage() {
  const [biography, setBiography] = useState('');
  const [error, setError] = useState('');
  const queryClient = useQueryClient();

  // Fetch about me data
  const { data: aboutMe, isLoading, error: fetchError } = useQuery({
    queryKey: ['about'],
    queryFn: aboutAPI.getAbout,
  });

  // Update about me mutation
  const updateAboutMutation = useMutation({
    mutationFn: aboutAPI.updateAbout,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['about'] });
      setError('');
    },
    onError: (error: any) => {
      setError(error.response?.data?.message || 'Failed to update biography. Please try again.');
    },
  });

  // Update form data when about me is loaded
  useEffect(() => {
    if (aboutMe) {
      setBiography(aboutMe.biography || '');
    }
  }, [aboutMe]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    updateAboutMutation.mutate({ biography });
  };

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
        </div>
      </DashboardLayout>
    );
  }

  if (fetchError) {
    return (
      <DashboardLayout>
        <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-md p-4">
          <p className="text-red-600 dark:text-red-400">
            Failed to load biography. Please refresh the page.
          </p>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <ProtectedRoute>
      <DashboardLayout>
        <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white flex items-center">
            <FileText className="mr-3 h-8 w-8 text-blue-600" />
            About Me Management
          </h1>
          <p className="mt-2 text-gray-600 dark:text-gray-400">
            Update your professional biography and personal story
          </p>
        </div>

        {error && (
          <div className="mb-6 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-md p-4">
            <p className="text-red-600 dark:text-red-400">{error}</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="bg-white dark:bg-gray-800 shadow rounded-lg p-6">
            <h2 className="text-lg font-medium text-gray-900 dark:text-white mb-6">
              Professional Biography
            </h2>
            
            <Textarea
              label="Biography"
              value={biography}
              onChange={(e) => setBiography(e.target.value)}
              placeholder="Tell your story... Share your background, experience, passion for development, and what drives you in your career."
              rows={12}
              required
            />
            
            <div className="mt-4 text-sm text-gray-500 dark:text-gray-400">
              <p>💡 Tips for a great biography:</p>
              <ul className="list-disc list-inside mt-2 space-y-1">
                <li>Start with a compelling introduction</li>
                <li>Highlight your key achievements and experiences</li>
                <li>Share your passion for technology and development</li>
                <li>Include your career goals and aspirations</li>
                <li>Keep it professional but personal</li>
              </ul>
            </div>
          </div>

          <div className="flex justify-end space-x-4">
            <Button
              type="submit"
              loading={updateAboutMutation.isPending}
              icon={Save}
            >
              Save Biography
            </Button>
          </div>
        </form>

        {updateAboutMutation.isSuccess && (
          <div className="mt-6 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-md p-4">
            <p className="text-green-600 dark:text-green-400">
              Biography updated successfully!
            </p>
          </div>
        )}

        {aboutMe && (
          <div className="mt-8 bg-gray-50 dark:bg-gray-800 rounded-lg p-6">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
              Last Updated
            </h3>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              {new Date(aboutMe.updatedAt).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              })}
            </p>
          </div>
        )}
      </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
