import axios from 'axios';

// API base URL - replace with your actual API endpoint
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api';
// console.log("base",process.env.NEXT_PUBLIC_API_URL);
// Create axios instance with default config
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
api.interceptors.request.use((config) => {
  if (typeof window !== 'undefined') {
    const token = localStorage.getItem('admin_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
  }
  return config;
});

// Response interceptor to handle auth errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Token expired or invalid
      if (typeof window !== 'undefined') {
        localStorage.removeItem('admin_token');
        window.location.href = '/admin/login';
      }
    }
    return Promise.reject(error);
  }
);

// Types
export interface LoginCredentials {
  email: string;
  password: string;
}

export interface LoginResponse {
  accessToken: string;
  refreshToken:string
  // user: {
  //   id: string;
  //   email: string;
  //   name: string;
  // };
}

export interface Profile {
  id: string;
  name: string;
  tagline: string;
  profilePicture?: string;
  email: string;
}

export interface AboutMe {
  id: string;
  biography: string;
  updatedAt: string;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  image?: string;
  technologies: string[];
  githubUrl?: string;
  liveUrl?: string;
  isCompleted: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CreateProjectData {
  title: string;
  description: string;
  image?: string;
  technologies: string[];
  githubUrl?: string;
  liveUrl?: string;
  isCompleted: boolean;
}

export interface Skill {
  id: string;
  name: string;
  category: string;
  proficiency: number; // 1-100
  icon?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CreateSkillData {
  name: string;
  category: string;
  proficiency: number;
  icon?: string;
}

// Auth API
export const authAPI = {
  // login: async (credentials: LoginCredentials): Promise<LoginResponse> => {
  login: async (credentials: LoginCredentials) => {

    const response = await api.post('/auth/login', credentials);
    console.log(response.data);

    // if(response.data.token){
    return response.data;

    // }
  },
};

// Profile API
export const profileAPI = {
  getProfile: async (): Promise<Profile> => {
    const response = await api.get('/admin/profile');
    return response.data;
  },
  updateProfile: async (data: Partial<Profile>): Promise<Profile> => {
    const response = await api.put('/profile', data);
    return response.data;
  },
};

// About Me API
export const aboutAPI = {
  getAbout: async (): Promise<AboutMe> => {
    const response = await api.get('/about');
    return response.data;
  },
  updateAbout: async (data: { biography: string }): Promise<AboutMe> => {
    const response = await api.put('/about', data);
    return response.data;
  },
};

// Projects API
export const projectsAPI = {
  getProjects: async (): Promise<Project[]> => {
    const response = await api.get('/projects');
    return response.data;
  },
  createProject: async (data: CreateProjectData): Promise<Project> => {
    const response = await api.post('/projects', data);
    return response.data;
  },
  updateProject: async (id: string, data: Partial<CreateProjectData>): Promise<Project> => {
    const response = await api.put(`/projects/${id}`, data);
    return response.data;
  },
  deleteProject: async (id: string): Promise<void> => {
    await api.delete(`/projects/${id}`);
  },
};

// Skills API
export const skillsAPI = {
  getSkills: async (): Promise<Skill[]> => {
    const response = await api.get('/skills');
    return response.data;
  },
  createSkill: async (data: CreateSkillData): Promise<Skill> => {
    const response = await api.post('/skills', data);
    return response.data;
  },
  updateSkill: async (id: string, data: Partial<CreateSkillData>): Promise<Skill> => {
    const response = await api.put(`/skills/${id}`, data);
    return response.data;
  },
  deleteSkill: async (id: string): Promise<void> => {
    await api.delete(`/skills/${id}`);
  },
};

export default api;
