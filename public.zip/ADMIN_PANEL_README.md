# Portfolio Admin Panel

A comprehensive admin panel for managing your portfolio website, built with Next.js, TypeScript, and Tailwind CSS.

## Features

### 🔐 Authentication
- Secure login system with JWT tokens
- Protected routes for all admin functionality
- Automatic token validation and refresh

### 📊 Dashboard
- **Profile Management**: Update personal information, tagline, and profile picture
- **About Me Management**: Edit professional biography and personal story
- **Projects Management**: Full CRUD operations for portfolio projects
- **Skills Management**: Manage technical skills with proficiency levels

### 🎨 Design & UX
- Modern, responsive design with Tailwind CSS
- Dark mode toggle
- Mobile-friendly sidebar navigation
- Beautiful form components and modals
- Loading states and error handling

### 🚀 Technical Features
- React Query (TanStack Query) for data fetching and caching
- TypeScript for type safety
- Axios for API communication
- Form validation and error handling
- Responsive design for all screen sizes

## Project Structure

```
src/
├── app/
│   └── admin/
│       ├── login/
│       │   └── page.tsx          # Login page
│       ├── dashboard/
│       │   ├── page.tsx          # Profile management
│       │   ├── about/
│       │   │   └── page.tsx      # About me management
│       │   ├── projects/
│       │   │   └── page.tsx      # Projects management
│       │   └── skills/
│       │       └── page.tsx      # Skills management
│       └── layout.tsx            # Admin layout with providers
├── components/
│   └── admin/
│       ├── auth/
│       │   └── protected-route.tsx
│       ├── layout/
│       │   └── dashboard-layout.tsx
│       └── ui/
│           └── form-components.tsx
├── contexts/
│   └── auth-context.tsx          # Authentication context
└── lib/
    └── api.ts                    # API service functions
```

## Setup Instructions

### 1. Install Dependencies

```bash
npm install @tanstack/react-query axios react-hook-form @hookform/resolvers zod js-cookie @types/js-cookie
```

### 2. Environment Variables

Create a `.env.local` file in your project root:

```env
NEXT_PUBLIC_API_URL=http://localhost:3001/api
```

Replace with your actual API endpoint.

### 3. API Endpoints

Your backend API should implement the following endpoints:

#### Authentication
- `POST /auth/login` - User login

#### Profile
- `GET /profile` - Get user profile
- `PUT /profile` - Update user profile

#### About Me
- `GET /about` - Get about me content
- `PUT /about` - Update about me content

#### Projects
- `GET /projects` - Get all projects
- `POST /projects` - Create new project
- `PUT /projects/:id` - Update project
- `DELETE /projects/:id` - Delete project

#### Skills
- `GET /skills` - Get all skills
- `POST /skills` - Create new skill
- `PUT /skills/:id` - Update skill
- `DELETE /skills/:id` - Delete skill

### 4. API Response Formats

#### Login Response
```json
{
  "token": "jwt_token_here",
  "user": {
    "id": "user_id",
    "email": "user@example.com",
    "name": "User Name"
  }
}
```

#### Profile
```json
{
  "id": "profile_id",
  "name": "Full Name",
  "tagline": "Professional Tagline",
  "profilePicture": "image_url",
  "email": "email@example.com"
}
```

#### About Me
```json
{
  "id": "about_id",
  "biography": "Professional biography text...",
  "updatedAt": "2024-01-01T00:00:00.000Z"
}
```

#### Project
```json
{
  "id": "project_id",
  "title": "Project Title",
  "description": "Project description...",
  "image": "image_url",
  "technologies": ["React", "Node.js"],
  "githubUrl": "https://github.com/...",
  "liveUrl": "https://demo.com",
  "isCompleted": true,
  "createdAt": "2024-01-01T00:00:00.000Z",
  "updatedAt": "2024-01-01T00:00:00.000Z"
}
```

#### Skill
```json
{
  "id": "skill_id",
  "name": "Skill Name",
  "category": "frontend",
  "proficiency": 75,
  "icon": "🚀",
  "createdAt": "2024-01-01T00:00:00.000Z",
  "updatedAt": "2024-01-01T00:00:00.000Z"
}
```

### 5. Usage

1. **Access Admin Panel**: Navigate to `/admin/login`
2. **Login**: Use your credentials to access the dashboard
3. **Navigate**: Use the sidebar to switch between different management sections
4. **Manage Content**: Add, edit, or delete your portfolio content
5. **View Portfolio**: Click "View Portfolio" to see your public portfolio

## Customization

### Styling
- Modify Tailwind classes in the components
- Update color schemes in the `form-components.tsx`
- Customize the sidebar and layout in `dashboard-layout.tsx`

### Form Validation
- Add Zod schemas for form validation
- Implement custom validation rules in the API service

### Additional Features
- Add more management sections (e.g., Blog Posts, Testimonials)
- Implement file upload functionality for images
- Add user management for multiple admin users
- Implement audit logs for content changes

## Security Considerations

- JWT tokens are stored in localStorage (consider httpOnly cookies for production)
- All admin routes are protected with authentication
- API endpoints should implement proper authorization
- Consider rate limiting for login attempts
- Implement CSRF protection for production use

## Browser Support

- Modern browsers with ES6+ support
- Responsive design for mobile and tablet devices
- Progressive enhancement for older browsers

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is open source and available under the [MIT License](LICENSE).

## Support

For questions or issues, please open an issue on GitHub or contact the development team.
